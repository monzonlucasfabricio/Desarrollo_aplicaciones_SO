gcc main.c Persona.c -o main
