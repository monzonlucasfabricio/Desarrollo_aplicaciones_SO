import random

LEN = 100000

num = []
for x in range(LEN):
	num.append(random.randint(0,LEN))


num.sort()

#print(num)

